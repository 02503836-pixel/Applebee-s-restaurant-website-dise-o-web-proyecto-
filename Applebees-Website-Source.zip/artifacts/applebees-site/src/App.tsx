import { type ReactNode } from 'react';
import { ErrorBoundary } from '@/components/error-boundary';
import { SiteShell } from '@/components/site-shell';
import AdsPage from '@/pages/ads';
import ContactPage from '@/pages/contact';
import HomePage from '@/pages/home';
import LocationsPage from '@/pages/locations';
import MenuPage from '@/pages/menu';
import { Link, Route, Router as WouterRouter, Switch, useLocation } from 'wouter';

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function NotFound() {
  return (
    <main id="main-content" className="not-found section-wrap">
      <p className="eyebrow" style={{ justifyContent: 'center' }}>Well, this is awkward</p>
      <h1 className="display-title">That table isn&apos;t here.</h1>
      <p className="body-copy">Let&apos;s get you back to the neighborhood.</p>
      <Link href="/" className="button-primary">Back to welcome</Link>
    </main>
  );
}

function Router() {
  return (
    <SiteShell>
      <RoutedErrorBoundary>
        <Switch>
          <Route path="/" component={HomePage} />
          <Route path="/menu" component={MenuPage} />
          <Route path="/locations" component={LocationsPage} />
          <Route path="/ads" component={AdsPage} />
          <Route path="/contact" component={ContactPage} />
          <Route component={NotFound} />
        </Switch>
      </RoutedErrorBoundary>
    </SiteShell>
  );
}

function App() {
  return (
    <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
      <Router />
    </WouterRouter>
  );
}

export default App;