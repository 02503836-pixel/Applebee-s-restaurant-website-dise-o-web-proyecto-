import { type ReactNode, useState } from 'react';
import { ArrowUpRight, Menu as MenuIcon, X } from 'lucide-react';
import { Link, useLocation } from 'wouter';

const navItems = [
  { href: '/', label: 'Welcome' },
  { href: '/menu', label: 'Our menu' },
  { href: '/locations', label: 'Locations' },
  { href: '/ads', label: 'On screen' },
  { href: '/contact', label: 'Contact' },
];

function Brand() {
  return (
    <span className="brand-link" aria-label="Applebee's Neighborhood Grill and Bar">
      <span className="brand-mark" aria-hidden="true">a</span>
      <span className="brand-name">
        applebee&apos;s
        <small>Neighborhood Grill + Bar</small>
      </span>
    </span>
  );
}

export function SiteHeader() {
  const [path] = useLocation();
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <>
      <div className="top-ribbon">
        <strong>Good food. Good people.</strong>
        <span>That&apos;s how the neighborhood gets together.</span>
      </div>
      <header className="site-header">
        <div className="header-inner">
          <Link href="/" className="brand-link" aria-label="Applebee's home" onClick={() => setMenuOpen(false)}>
            <Brand />
          </Link>
          <nav id="main-navigation" className={`primary-nav${menuOpen ? ' is-open' : ''}`} aria-label="Main navigation">
            {navItems.map((item) => (
              <Link
                href={item.href}
                key={item.href}
                aria-current={path === item.href ? 'page' : undefined}
                onClick={() => setMenuOpen(false)}
                data-testid={`link-nav-${item.label.toLowerCase().replaceAll(' ', '-')}`}
              >
                {item.label}
              </Link>
            ))}
          </nav>
          <Link href="/locations" className="header-cta">
            Find a grill <ArrowUpRight size={15} aria-hidden="true" />
          </Link>
          <button
            className="mobile-toggle"
            type="button"
            aria-label={menuOpen ? 'Close navigation menu' : 'Open navigation menu'}
            aria-expanded={menuOpen}
            aria-controls="main-navigation"
            onClick={() => setMenuOpen((open) => !open)}
            data-testid="button-mobile-menu"
          >
            {menuOpen ? <X size={20} /> : <MenuIcon size={20} />}
          </button>
        </div>
      </header>
    </>
  );
}

export function SiteFooter() {
  return (
    <footer className="site-footer">
      <div className="section-wrap">
        <div className="footer-main">
          <div className="footer-brand">
            <Link href="/" aria-label="Applebee's home"><Brand /></Link>
            <p>Neighborhood Grill + Bar. A familiar table for weeknight dinners, big games, and all the good stuff in between.</p>
          </div>
          <div className="footer-column">
            <h2>Come on in</h2>
            <div className="footer-links">
              <Link href="/menu">Explore the menu</Link>
              <Link href="/locations">Find a location</Link>
              <Link href="/ads">Watch the latest ads</Link>
            </div>
          </div>
          <div className="footer-column">
            <h2>Say hello</h2>
            <div className="footer-links">
              <Link href="/contact">Contact this project</Link>
              <a href="https://www.youtube.com/@applebees" target="_blank" rel="noreferrer">Applebee&apos;s on YouTube <ArrowUpRight size={12} aria-hidden="true" /></a>
            </div>
          </div>
        </div>
        <div className="footer-bottom">
          <address className="student-credit" aria-label="Project author">
            <span className="student-credit-label">Proyecto de</span>
            <strong>Jury Kazumi Bona Francisco</strong>
            <span>Matrícula: 02503836</span>
            <a href="mailto:02503836@cobachbc.edu.mx">Correo electrónico: 02503836@cobachbc.edu.mx</a>
          </address>
          <span>© 2026 Neighborhood Grill concept</span>
          <span className="disclaimer">Independent school project concept. Not an official Applebee&apos;s website. Menu offerings, prices, and promotions can vary by location.</span>
        </div>
      </div>
    </footer>
  );
}

export function SiteShell({ children }: { children: ReactNode }) {
  return (
    <div className="site-shell">
      <a className="skip-link" href="#main-content">Skip to main content</a>
      <SiteHeader />
      {children}
      <SiteFooter />
    </div>
  );
}