import { useState } from 'react';

/**
 * Reusable, local-only image slot. Add your own file at public/images/your-image.jpg.
 * If no file is present, the CSS-designed illustration remains as the placeholder.
 */
export function LocalImageSlot() {
  const [imageMissing, setImageMissing] = useState(false);

  return (
    <div className={`local-image-slot${imageMissing ? ' is-empty' : ''}`}>
      {!imageMissing && (
        <img
          // Replace this exact local source path with your image file, e.g. /images/my-dinner.jpg.
          src="/images/your-image.jpg"
          alt="A plate of grilled neighborhood favorites, ready to share around the table"
          onError={() => setImageMissing(true)}
        />
      )}
      <div className="image-fallback" aria-hidden="true">
        <div className="fallback-food" />
        <span className="fallback-caption">Your local photo goes here</span>
      </div>
    </div>
  );
}