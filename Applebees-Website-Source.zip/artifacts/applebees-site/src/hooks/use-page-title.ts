import { useEffect } from 'react';

export function usePageTitle(title: string, description: string) {
  useEffect(() => {
    document.title = `${title} | Applebee's Neighborhood Grill`;
    const descriptionTag = document.querySelector<HTMLMetaElement>('meta[name="description"]');
    if (descriptionTag) descriptionTag.content = description;
  }, [title, description]);
}