import { ArrowRight, MapPin, Play, Utensils } from 'lucide-react';
import { Link } from 'wouter';
import { LocalImageSlot } from '@/components/local-image-slot';
import { usePageTitle } from '@/hooks/use-page-title';

export default function HomePage() {
  usePageTitle('Welcome', 'A lively neighborhood grill for weeknight dinners, game-day meetups, and easy takeout.');

  return (
    <main id="main-content" className="page-main">
      <section className="hero" aria-labelledby="welcome-title">
        <div className="hero-grid">
          <div className="hero-copy">
            <p className="eyebrow">Neighborhood Grill + Bar</p>
            <h1 id="welcome-title" className="display-title">Good things happen <em>around</em> the table.</h1>
            <p className="hero-intro">A booth for the whole crew. A plate worth passing around. And one more reason to stay a little longer.</p>
            <div className="hero-actions">
              <Link href="/menu" className="button-primary">See what&apos;s cooking <ArrowRight size={16} aria-hidden="true" /></Link>
              <Link href="/locations" className="button-outline"><MapPin size={15} aria-hidden="true" /> Find your neighborhood</Link>
            </div>
          </div>
          <div className="hero-art" aria-label="Featured neighborhood-style meal">
            <LocalImageSlot />
            <div className="hero-stamp" aria-hidden="true">Since<br /><span>1980</span><br />Good times</div>
          </div>
        </div>
        <div className="hero-foot"><span>Good food is better together</span><span>Made for your kind of night</span></div>
      </section>

      <section className="welcome-promo" aria-labelledby="whats-on-title">
        <div className="section-wrap">
          <div className="promo-head">
            <div>
              <span className="section-kicker">A little something for everyone</span>
              <h2 id="whats-on-title" className="section-heading">Make tonight a good one.</h2>
            </div>
            <p className="body-copy">The classics you came for, plus a few reasons to bring the group chat along.</p>
          </div>
          <div className="feature-grid">
            <article className="feature-card">
              <span className="number">01 / Dinner plans, handled</span>
              <span className="feature-graphic" aria-hidden="true">2</span>
              <div>
                <h3>Two favorites. One easy night.</h3>
                <p>Make it a date, a catch-up, or a reason to skip the dishes. Our shareable favorites keep dinner simple.</p>
                <Link href="/menu">Explore the menu <ArrowRight size={14} aria-hidden="true" /></Link>
              </div>
            </article>
            <article className="feature-card">
              <span className="number">02 / Game-day energy</span>
              <span className="feature-graphic" aria-hidden="true">W</span>
              <div>
                <h3>Wings for the whole huddle.</h3>
                <p>Big plays call for a table full of wings. Settle in for the season together.</p>
                <Link href="/ads">Catch the latest spot <Play size={13} aria-hidden="true" /></Link>
              </div>
            </article>
            <article className="feature-card">
              <span className="number">03 / Your place or ours</span>
              <span className="feature-graphic" aria-hidden="true">GO</span>
              <div>
                <h3>Bring the grill home.</h3>
                <p>Pick up something good on your way home. Easy dinner, no big production.</p>
                <Link href="/locations">Find To Go nearby <ArrowRight size={14} aria-hidden="true" /></Link>
              </div>
            </article>
          </div>
        </div>
      </section>

      <section className="social-band" aria-labelledby="favorites-title">
        <div className="section-wrap social-inner">
          <div>
            <span className="section-kicker" style={{ color: '#f3cf59' }}>Familiar favorites, with a little extra</span>
            <h2 id="favorites-title">Comfort food has a way of bringing everybody to the table.</h2>
            <p>Think Four-Cheese Mac &amp; Cheese, Loaded Potato Waves, a Grilled Cheese Cheeseburger, and Lemon Parmesan Chicken.</p>
          </div>
          <Link href="/menu" className="button-outline"><Utensils size={15} aria-hidden="true" /> Meet the menu</Link>
        </div>
      </section>

      <section className="pullquote" aria-label="A neighborhood welcome">
        <div className="section-wrap">
          <blockquote>“Come as you are. <span>Leave a little happier.</span>”</blockquote>
          <cite>That&apos;s the neighborhood kind of thing.</cite>
        </div>
      </section>
    </main>
  );
}