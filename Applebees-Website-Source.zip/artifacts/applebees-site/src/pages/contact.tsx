import { useState, type FormEvent } from 'react';
import { z } from 'zod';
import { ArrowRight, Check } from 'lucide-react';
import { usePageTitle } from '@/hooks/use-page-title';

const contactSchema = z.object({
  name: z.string().trim().min(2, 'Please enter at least 2 characters.'),
  email: z.string().trim().email('Enter a valid email address.'),
  topic: z.string().min(1, 'Choose a topic so we know where to direct your note.'),
  phone: z.string().optional(),
  message: z.string().trim().min(15, 'Tell us a little more (at least 15 characters).').max(1200, 'Please keep your message under 1,200 characters.'),
});

export default function ContactPage() {
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});
  const [submittedName, setSubmittedName] = useState('');
  usePageTitle('Contact', 'Send a note using this accessible, validated class-project contact form.');

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = event.currentTarget;
    const formData = new FormData(form);
    const values = {
      name: String(formData.get('name') ?? ''),
      email: String(formData.get('email') ?? ''),
      topic: String(formData.get('topic') ?? ''),
      phone: String(formData.get('phone') ?? ''),
      message: String(formData.get('message') ?? ''),
    };
    const result = contactSchema.safeParse(values);
    if (!result.success) {
      const errors = Object.fromEntries(
        Object.entries(result.error.flatten().fieldErrors).map(([key, messages]) => [key, messages?.[0] ?? '']),
      ) as Record<string, string>;
      setFieldErrors(errors);
      setSubmittedName('');
      return;
    }
    setFieldErrors({});
    setSubmittedName(result.data.name);
    form.reset();
  }

  return (
    <main id="main-content" className="page-main">
      <header className="page-hero">
        <div className="section-wrap">
          <p className="eyebrow">We&apos;re listening</p>
          <h1 className="display-title">Drop us a line.</h1>
          <p>Tell us what&apos;s on your mind. This class-project form is a visual demo; your message stays right here in the browser.</p>
        </div>
      </header>
      <section className="content-section" aria-labelledby="contact-heading">
        <div className="section-wrap contact-layout">
          <aside className="contact-aside">
            <span className="section-kicker">A note to the neighborhood</span>
            <h2 id="contact-heading">Good conversations start somewhere.</h2>
            <p>Questions, a favorite menu memory, or just a quick hello — we made a little room for it here.</p>
            <div className="aside-rule" />
            <p><strong>Just so you know</strong><br />This is an independent school project. The form does not send or store information.</p>
          </aside>
          <div>
            {submittedName && (
              <div className="success-message" role="status" aria-live="polite" data-testid="status-contact-success">
                <Check size={20} aria-hidden="true" />
                <div><strong>Thanks for reaching out, {submittedName}.</strong><span>Your note was received in this demo. Nothing was sent to a server.</span></div>
              </div>
            )}
            <form className="contact-form" onSubmit={handleSubmit} aria-describedby="form-disclaimer">
              <div className="form-grid">
                <div className="form-field">
                  <label htmlFor="contact-name">Your name <span aria-hidden="true">*</span></label>
                  <input className="text-field" id="contact-name" name="name" type="text" autoComplete="name" required minLength={2} maxLength={80} aria-invalid={Boolean(fieldErrors.name)} aria-describedby={fieldErrors.name ? 'error-name' : undefined} data-testid="input-contact-name" />
                  {fieldErrors.name && <span className="field-error" id="error-name" role="alert">{fieldErrors.name}</span>}
                </div>
                <div className="form-field">
                  <label htmlFor="contact-email">Email address <span aria-hidden="true">*</span></label>
                  <input className="text-field" id="contact-email" name="email" type="email" autoComplete="email" required aria-invalid={Boolean(fieldErrors.email)} aria-describedby={fieldErrors.email ? 'error-email' : undefined} data-testid="input-contact-email" />
                  {fieldErrors.email && <span className="field-error" id="error-email" role="alert">{fieldErrors.email}</span>}
                </div>
                <div className="form-field">
                  <label htmlFor="contact-topic">What&apos;s this about? <span aria-hidden="true">*</span></label>
                  <select className="text-field" id="contact-topic" name="topic" defaultValue="" required aria-invalid={Boolean(fieldErrors.topic)} aria-describedby={fieldErrors.topic ? 'error-topic' : undefined} data-testid="select-contact-topic">
                    <option value="" disabled>Select a topic</option>
                    <option value="menu">Menu and favorites</option>
                    <option value="visit">Planning a visit</option>
                    <option value="feedback">Share feedback</option>
                    <option value="other">Something else</option>
                  </select>
                  {fieldErrors.topic && <span className="field-error" id="error-topic" role="alert">{fieldErrors.topic}</span>}
                </div>
                <div className="form-field">
                  <label htmlFor="contact-phone">Phone <span>(optional)</span></label>
                  <input className="text-field" id="contact-phone" name="phone" type="tel" autoComplete="tel" />
                </div>
                <div className="form-field wide">
                  <label htmlFor="contact-message">Your message <span aria-hidden="true">*</span></label>
                  <textarea className="textarea-field" id="contact-message" name="message" required minLength={15} maxLength={1200} placeholder="Tell us a little more..." aria-invalid={Boolean(fieldErrors.message)} aria-describedby={fieldErrors.message ? 'error-message' : 'message-hint'} data-testid="input-contact-message" />
                  {fieldErrors.message ? <span className="field-error" id="error-message" role="alert">{fieldErrors.message}</span> : <span className="field-error" id="message-hint">15–1,200 characters</span>}
                </div>
              </div>
              <div className="form-actions">
                <span className="form-privacy" id="form-disclaimer">Required fields are marked with an asterisk. No backend is connected to this school project.</span>
                <button className="button-primary" type="submit">Send your note <ArrowRight size={15} aria-hidden="true" /></button>
              </div>
            </form>
          </div>
        </div>
      </section>
    </main>
  );
}