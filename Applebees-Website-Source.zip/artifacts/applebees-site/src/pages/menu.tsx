import { useMemo, useState } from 'react';
import { usePageTitle } from '@/hooks/use-page-title';

type MenuCategory = 'Starters' | 'Mains' | 'Favorites';
type MenuItem = {
  name: string;
  description: string;
  price: number;
  category: MenuCategory;
  image: string;
  imageAlt: string;
  note?: string;
};

const categories = ['All', 'Starters', 'Mains', 'Favorites'] as const;
const menuItems: MenuItem[] = [
  { name: 'Loaded Potato Waves', description: 'Crisp potato slices with melted cheese, bacon, and a cool ranch finish. Built for passing around.', price: 199, category: 'Starters', image: '/images/menu/applebees-menu-loaded-potato-waves.jpg', imageAlt: 'Crispy potato rounds topped with cheese, bacon, ranch, and chives', note: 'A table favorite' },
  { name: 'Boneless Wings', description: 'Crispy all-white-meat chicken tossed in your pick of bold, tangy sauce.', price: 249, category: 'Starters', image: '/images/menu/applebees-menu-boneless-wings.jpg', imageAlt: 'Crispy boneless wings served with ranch dip and celery', note: 'Game-day ready' },
  { name: 'Four-Cheese Mac & Cheese', description: 'Creamy, cozy elbow macaroni with a rich four-cheese sauce and a golden breadcrumb top.', price: 309, category: 'Favorites', image: '/images/menu/applebees-menu-four-cheese-mac.jpg', imageAlt: 'Creamy macaroni and cheese with a golden breadcrumb topping', note: 'Comfort, covered' },
  { name: 'Grilled Cheese Cheeseburger', description: 'A juicy burger stacked between buttery grilled cheese sandwiches. No wrong way to do dinner.', price: 319, category: 'Favorites', image: '/images/menu/applebees-menu-grilled-cheese-cheeseburger.jpg', imageAlt: 'Cheeseburger stacked between golden grilled cheese sandwiches', note: 'Big appetite energy' },
  { name: 'Lemon Parmesan Chicken', description: 'Grilled chicken with bright lemon, savory parmesan, and a fresh, simple finish.', price: 349, category: 'Mains', image: '/images/menu/applebees-menu-lemon-parmesan-chicken.jpg', imageAlt: 'Grilled chicken topped with lemon parmesan and served with vegetables', note: 'A lighter favorite' },
  { name: 'Classic Riblet Plate', description: 'Saucy, tender riblets served with classic sides and plenty of napkins.', price: 359, category: 'Mains', image: '/images/menu/applebees-menu-classic-riblet-plate.jpg', imageAlt: 'Barbecue-glazed riblets with fries and coleslaw', },
  { name: 'Chicken Tenders Platter', description: 'Golden, crispy tenders with dipping sauce and the sides you like best.', price: 299, category: 'Mains', image: '/images/menu/applebees-menu-chicken-tenders-platter.jpg', imageAlt: 'Golden chicken tenders with fries and dipping sauce', },
  { name: 'Spinach & Artichoke Dip', description: 'A warm, creamy shareable with spinach, artichoke, and crisp tortilla chips.', price: 209, category: 'Starters', image: '/images/menu/applebees-menu-spinach-artichoke-dip.jpg', imageAlt: 'Warm spinach artichoke dip with golden tortilla chips', },
];

const formatMxPrice = (price: number) => `MXN ${new Intl.NumberFormat('es-MX').format(price)}`;

export default function MenuPage() {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const visibleItems = useMemo(
    () => selectedCategory === 'All' ? menuItems : menuItems.filter((item) => item.category === selectedCategory),
    [selectedCategory],
  );
  usePageTitle('Menu', 'Browse neighborhood favorites with food photos, descriptions, and sample prices in Mexican pesos (MXN).');

  return (
    <main id="main-content" className="page-main">
      <header className="page-hero">
        <div className="section-wrap">
          <p className="eyebrow">Pull up a chair</p>
          <h1 className="display-title">Come hungry.<br />Leave happy.</h1>
          <p>Big, familiar flavors for the moments that turn into the whole evening. Here&apos;s a taste of the neighborhood.</p>
        </div>
      </header>
      <section className="content-section" aria-labelledby="menu-list-title">
        <div className="section-wrap">
          <div className="menu-toolbar">
            <div>
              <span className="section-kicker">The good stuff</span>
              <h2 id="menu-list-title" className="section-heading">A few local favorites</h2>
            </div>
            <div className="menu-note" aria-live="polite">
              <span>{visibleItems.length} neighborhood picks</span>
              <span className="menu-currency">Prices in Mexican pesos (MXN)</span>
            </div>
          </div>
          <div className="menu-tabs" role="group" aria-label="Filter menu by category">
            {categories.map((category) => (
              <button
                key={category}
                type="button"
                className="filter-button"
                aria-pressed={selectedCategory === category}
                onClick={() => setSelectedCategory(category)}
                data-testid={`button-filter-${category.toLowerCase()}`}
              >
                {category}
              </button>
            ))}
          </div>
          <div className="menu-grid" aria-live="polite">
            {visibleItems.map((item) => (
              <article className="menu-item" key={item.name} data-testid={`menu-item-${item.name.toLowerCase().replace(/[^a-z0-9]+/g, '-')}`}>
                <img className="menu-item-photo" src={item.image} alt={item.imageAlt} loading="lazy" decoding="async" />
                <div className="menu-item-copy">
                  <div className="menu-item-heading">
                    <h3>{item.name}</h3>
                    <span className="price">{formatMxPrice(item.price)}</span>
                  </div>
                  <p>{item.description}</p>
                  {item.note && <span className="menu-tag">{item.note}</span>}
                </div>
              </article>
            ))}
          </div>
          <p className="menu-footer-note">All prices are illustrative and shown in Mexican pesos (MXN); they are not official Applebee&apos;s prices. Menu items and prices may vary by restaurant. Food photos are illustrative.</p>
        </div>
      </section>
    </main>
  );
}