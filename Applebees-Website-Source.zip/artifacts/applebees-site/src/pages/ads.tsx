import { ArrowUpRight } from 'lucide-react';
import { usePageTitle } from '@/hooks/use-page-title';

const commercials = [
  { id: 'GjmwW9kopss', title: "Applebee's 2026 Commercial - Return of the Big Easy", label: '01 / New Orleans, neighborhood style' },
  { id: 'rlRhlpHDJv0', title: "Applebee's Commercial 2026 - (USA)", label: '02 / A little more together' },
];

export default function AdsPage() {
  usePageTitle('On screen', 'Watch two existing Applebee’s commercial clips on YouTube and visit the official channel.');

  return (
    <main id="main-content" className="page-main">
      <header className="page-hero">
        <div className="section-wrap">
          <p className="eyebrow">From the neighborhood, to your screen</p>
          <h1 className="display-title">Good stories.<br />Good company.</h1>
          <p>A couple of recent spots from the Applebee&apos;s grill-and-bar world. Settle in and press play.</p>
        </div>
      </header>
      <section className="content-section" aria-labelledby="commercials-heading">
        <div className="section-wrap">
          <div className="ads-intro">
            <div>
              <span className="section-kicker">The latest from the screen</span>
              <h2 id="commercials-heading" className="section-heading">Pull up a clip.</h2>
            </div>
            <p className="body-copy">Two existing Applebee&apos;s commercial clips on YouTube, embedded with YouTube&apos;s privacy-enhanced player.</p>
          </div>
          <div className="video-list">
            {commercials.map((commercial) => (
              <article className="video-card" key={commercial.id} data-testid={`video-card-${commercial.id}`}>
                <iframe
                  className="video-frame"
                  src={`https://www.youtube-nocookie.com/embed/${commercial.id}?rel=0`}
                  title={commercial.title}
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                  referrerPolicy="strict-origin-when-cross-origin"
                  allowFullScreen
                />
                <div className="video-details">
                  <span className="video-label">{commercial.label}</span>
                  <h2>{commercial.title}</h2>
                </div>
              </article>
            ))}
          </div>
          <div className="channel-note">
            <p>Want more? Visit the official Applebee&apos;s channel for more of what&apos;s on screen.</p>
            <a className="button-dark" href="https://www.youtube.com/@applebees" target="_blank" rel="noreferrer">
              Visit @applebees <ArrowUpRight size={15} aria-hidden="true" />
            </a>
          </div>
        </div>
      </section>
    </main>
  );
}