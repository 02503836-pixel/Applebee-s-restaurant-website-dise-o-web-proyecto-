import { useState, type FormEvent } from 'react';
import { ArrowUpRight, MapPin, Navigation } from 'lucide-react';
import { usePageTitle } from '@/hooks/use-page-title';

export default function LocationsPage() {
  const [place, setPlace] = useState('');
  const [searchedPlace, setSearchedPlace] = useState('');
  const query = `Applebee's${searchedPlace ? ` near ${searchedPlace}` : ' restaurants in the United States'}`;
  const encodedQuery = encodeURIComponent(query);
  const embedUrl = `https://www.google.com/maps?q=${encodedQuery}&output=embed`;
  const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${encodedQuery}`;
  usePageTitle('Locations', 'Search for an Applebee’s Neighborhood Grill by city, state, or ZIP code.');

  function handleSearch(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setSearchedPlace(place.trim());
  }

  return (
    <main id="main-content" className="page-main">
      <header className="page-hero">
        <div className="section-wrap">
          <p className="eyebrow">Right around the corner</p>
          <h1 className="display-title">There&apos;s a seat<br />with your name on it.</h1>
          <p>Find your neighborhood grill. Enter a city, state, or ZIP and we&apos;ll pull up a map search, ready for you.</p>
        </div>
      </header>
      <section className="content-section" aria-labelledby="locations-search-heading">
        <div className="section-wrap">
          <div className="locations-layout">
            <div className="location-search-card">
              <h2 id="locations-search-heading">Find your grill.</h2>
              <p>Start with a city or ZIP. Google Maps will show nearby Applebee&apos;s locations and directions.</p>
              <form className="location-form" onSubmit={handleSearch}>
                <div>
                  <label className="field-label" htmlFor="place-search">City, state, or ZIP code</label>
                  <input
                    id="place-search"
                    className="text-field"
                    type="search"
                    placeholder="For example, Columbus, OH"
                    value={place}
                    onChange={(event) => setPlace(event.target.value)}
                    required
                    autoComplete="postal-code"
                    data-testid="input-location-search"
                  />
                </div>
                <button className="button-primary" type="submit"><MapPin size={15} aria-hidden="true" /> Search locations</button>
              </form>
              <div className="location-callout">
                <span className="callout-icon"><Navigation size={17} aria-hidden="true" /></span>
                <div>
                  <strong>Good times, close by.</strong>
                  <span>Use the map to open directions, check the route, and choose a spot that works for your crew.</span>
                </div>
              </div>
            </div>
            <div>
              <iframe
                className="map-frame"
                src={embedUrl}
                title={`Google Maps search for ${query}`}
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                data-testid="map-locations"
              />
              <div className="map-note">
                <span>{searchedPlace ? `Showing Applebee's near ${searchedPlace}` : 'Explore Applebee’s locations across the United States'}</span>
                <a className="text-link" href={mapsUrl} target="_blank" rel="noreferrer">
                  Open in Google Maps <ArrowUpRight size={13} aria-hidden="true" />
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}