Applebee's Neighborhood Grill website source

The website project is in artifacts/applebees-site/.
Menu photos are included in artifacts/applebees-site/public/images/menu/.
This source archive also includes the workspace configuration and shared libraries used by the website.

The site was built as a pnpm + React + Vite workspace. The homepage's local hero image slot is intentionally left for your own photo.
